# encoding: utf-8

HOST = 'localhost'
CGI  = '/upload'
PORT = 4567
